﻿using System.Collections.Generic;
using BucketNetting.Model;

namespace BucketNetting.Services
{
    public interface IAllocateToBucketService
    {
        Dictionary<int, List<Asset>> Allocate(Portfolio portfolio);
        decimal GetMarketValue(Dictionary<int, List<Asset>> buckets);
    }
}
