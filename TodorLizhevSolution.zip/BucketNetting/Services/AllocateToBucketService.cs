﻿using System.Collections.Generic;
using System.Linq;
using BucketNetting.Model;

namespace BucketNetting.Services
{
    public class AllocateToBucketService : IAllocateToBucketService
    {
        public Dictionary<int, List<Asset>> Allocate(Portfolio portfolio)
        {
            var buckets = new Dictionary<int, List<Asset>>()
            {
                {1, new()},
                {2, new()},
                {3, new()},
                {4, new()},
            };

            foreach (var asset in portfolio.Assets)
            {
                if (asset.Class is "Future")
                {
                    if ((asset.MaturityDate - portfolio.DataDate).TotalDays < 730)
                    {
                        buckets[1].Add(asset);
                        continue;
                    } 
                    if ((asset.MaturityDate - portfolio.DataDate).TotalDays < 2555)
                    {
                        buckets[2].Add(asset);
                    }                    
                    if ((asset.MaturityDate - portfolio.DataDate).TotalDays < 5475)
                    {
                        buckets[3].Add(asset);
                    }
                    if ((asset.MaturityDate - portfolio.DataDate).TotalDays > 5475)
                    {
                        buckets[4].Add(asset);
                    }
                }
            }

            return buckets;
        }

        public decimal GetMarketValue(Dictionary<int, List<Asset>> buckets)
        {
            //buckets is {Count: > 0}
            //    throw an exception

            //return buckets.Values.SelectMany(x => x).Sum(x => x.MarketValue);
            return buckets.Keys.Sum();
        }
    }
}
